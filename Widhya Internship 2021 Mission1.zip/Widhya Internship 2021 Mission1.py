#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd


# In[3]:


data=pd.read_csv("bitcoin_dataset.csv")


# In[4]:


data.head()


# In[5]:


print(data[data["btc_market_price"]==1025].index.values)


# In[28]:


(data[data["btc_market_price"]==1024].index.values)


# In[7]:


index_value=data["btc_market_price"]
index_value[1023]


# # Exploratary Data Analysis

# In[9]:


import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[12]:


correlation=data.corr()
correlation


# In[14]:


sns.heatmap(correlation,cmap="Blues")


# # Linear Regression to predict the values

# In[20]:


from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn import metrics


# In[16]:


data.head()


# In[18]:


#preparing the data
x=data[["btc_market_cap","btc_n_transactions_per_block","btc_cost_per_transaction_percent","btc_cost_per_transaction"]].values
y=data["btc_market_price"].values


# In[19]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# In[22]:


regressor=LinearRegression()
regressor.fit(x_train,y_train)


# In[23]:


print(regressor.coef_)


# In[24]:


y_pred=regressor.predict(x_test)


# In[25]:


print("Mean Square Error:",metrics.mean_squared_error(y_test,y_pred))


# In[ ]:




