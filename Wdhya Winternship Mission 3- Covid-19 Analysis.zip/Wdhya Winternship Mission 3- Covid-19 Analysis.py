#!/usr/bin/env python
# coding: utf-8

# In[37]:


import  pandas as pd
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import math 
import seaborn as sns


# In[52]:


data=pd.read_csv("C:/Users/shristi/Desktop/Asus/Asus folder/Placement and Intership/Widhya Internship/covid-19 data.csv")
data.head()


# In[3]:


grouped=data.sort_values(['ConfirmedIndianNational','ConfirmedForeignNational','Cured','Deaths'],ascending=False).groupby('Date')


# In[60]:


grouped.head(20)


# In[61]:


total_cases=data.sum(axis=1,skipna=True)


# In[62]:


total_cases.head()


# In[51]:


fig_dims = (10,8)
fig, ax = plt.subplots(figsize=fig_dims)


sns.barplot(x='Date',y='ConfirmedIndianNational',data=data,ax=ax)


# In[67]:


plt.figure(figsize=(18,15))
plt.plot(data['Date'])
plt.title("Covid Cases in India")
plt.xlabel('Date')
plt.ylabel('total_cases')
plt.show()


# In[ ]:


#For microtask 5 
r=0.07692,t=26,P0=21
#which gives answer as 229

